#include <iostream>
using namespace std;

class coord
{
	int m_x, m_y;\
public:
	coord() { m_x = 0; m_y = 0; }
	coord(int x, int y) { m_x = x; m_y = y; }

	friend istream& operator >> (istream& ins, coord &a); 
	friend ostream& operator << (ostream& stream, coord a); 

};
 ostream& operator << (ostream& stream, coord a)
{
	 stream << a.m_x << ", " << a.m_y << '\n';
	 return stream;

}

istream& operator >> (istream& ins, coord &a)
{
	cout << "Enter Coordinates:	";
	ins >> a.m_x;
	ins >> a.m_y;
	return ins;
}

int main()
{
	coord ob1(1, 1), ob2(10, 23);
	cout << ob1 << ob2;

	cin >> ob1 >> ob2;
	cout << ob1 << ob2;

	system("PAUSE");
	return 0;
}