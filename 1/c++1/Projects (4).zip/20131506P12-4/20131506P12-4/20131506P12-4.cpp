#include <iostream>
using namespace std;

template <class T> class Array {
protected:
	T* m_arr;
	int m_maxSize;
	int m_curSize;
public:
	Array(int size = 3)
	{
		m_maxSize = size;
		m_curSize = 0;
		m_arr = new T[m_maxSize];
	}
	~Array()
	{
		free(m_arr);
	}
	void Add(int data)
	{
		if (m_curSize >= m_maxSize)
		{
			T* tmp = m_arr;
			m_maxSize += 3;
			m_arr = new T[m_maxSize];
			for (int i = 0; i < m_curSize; i++)
				m_arr[i] = tmp[i];
			delete[] tmp;
		}
		m_arr[m_curSize] = data;
		m_curSize++;
	}
	T GetAt(int index)
	{
		return m_arr[index];
	}
	int GetSize()
	{
		return m_maxSize-1;
	}
};

int main()
{
	Array<int> arr;
	int num;
	cout << "������ �Է��ϼ���(-1�̸� ����):";
	cin >> num;
	while (num != -1)
	{
		arr.Add(num);
		cout << "������ �Է��ϼ���(-1�̸� ����):";
		cin >> num;
	}
	cout << "�Էõ� ����: ";
	for (int i = 0; i <arr.GetSize(); i++)
	{
		cout<<arr.GetAt(i) << " ";
	}
	cout << "\n";

	return 0;
}

