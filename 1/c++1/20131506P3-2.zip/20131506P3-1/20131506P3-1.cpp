#include<iostream>
using namespace std;

const int Arrsize = 20;

int main() {
	cout << "�Ųٷ� ����� �ܾ �Է��ϼ���:";
	char word[Arrsize];
	cin >> word;

	for (int i = strlen(word) - 1; i < strlen(word) ; --i) {
		cout << word[i];
	}
	cout << endl;
	system("PAUSE");
	return 0;
}