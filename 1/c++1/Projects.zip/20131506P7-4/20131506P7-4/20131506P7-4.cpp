#include <iostream>
using namespace std;

class myclass {
	static int m_data;
public:

	void SetData(int n) { m_data = n; }
	int GetData() { return m_data; }
};

int myclass::m_data;

int main() {
	myclass ob1, ob2;
	ob1.SetData(100);
	ob2.SetData(200);
	cout << "ob1�� m_data����" << ob1.GetData() << "\n";
	cout << "ob2�� m_data����" << ob2.GetData() << "\n";

	return 0;
}
